# Insert your TOGETHER_API_KEY and remove '.example' from the file name 
TOGETHER_API_KEY="607a884b3f752a0e2bb61f7e0faa736958ebe84159b87f90fd6b480a7c0c9798"