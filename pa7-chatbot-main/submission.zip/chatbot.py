# PA7, CS124, Stanford
# v.1.1.0
#
# Original Python code by Ignacio Cases (@cases)
# Update: 2024-01: Added the ability to run the chatbot as LLM interface (@mryan0)
# Update: 2025-01 for Winter 2025 (Xuheng Cai)
######################################################################
import util
from pydantic import BaseModel, Field

import numpy as np
import re
import random

# noinspection PyMethodMayBeStatic
class Chatbot:
    """Simple class to implement the chatbot for PA 7."""

    def __init__(self, llm_enabled=False):
        # The chatbot's default name is `moviebot`.
        # TODO: Give your chatbot a new name.
        self.name = 'Barkbuster the Movie Pup'

        self.llm_enabled = llm_enabled

        # This matrix has the following shape: num_movies x num_users
        # The values stored in each row i and column j is the rating for
        # movie i by user j
        self.titles, ratings = util.load_ratings('data/ratings.txt')
        self.sentiment = util.load_sentiment_dictionary('data/sentiment.txt')

        ########################################################################
        # TODO: Binarize the movie ratings matrix.                             #
        ########################################################################

        # Binarize the movie ratings before storing the binarized matrix.
        self.ratings = self.binarize(ratings)
        self.movieCount = 0
        self.recCount = 0

        ########################################################################
        #                             END OF YOUR CODE                         #
        ########################################################################

    ############################################################################
    # 1. WARM UP REPL                                                          #
    ############################################################################

    def greeting(self):
        """Return a message that the chatbot uses to greet the user."""
        ########################################################################
        # TODO: Write a short greeting message                                 #
        ########################################################################

        greeting_message = "Hi! I'm a Movie Bot. Please tell me about a recent movie that you've seen. What have you liked/disliked? Please put the movie title in quotes."

        ########################################################################
        #                             END OF YOUR CODE                         #
        ########################################################################
        return greeting_message

    def goodbye(self):
        """
        Return a message that the chatbot uses to bid farewell to the user.
        """
        ########################################################################
        # TODO: Write a short farewell message                                 #
        ########################################################################

        goodbye_message = "Bye! Nice talking with you. Have a great day!"

        ########################################################################
        #                          END OF YOUR CODE                            #
        ########################################################################
        return goodbye_message
    

    ############################################################################
    # 2. Modules 2 and 3: extraction and transformation                        #
    ############################################################################

    def process(self, line):
        """Process a line of input from the REPL and generate a response.

        This is the method that is called by the REPL loop directly with user
        input.

        You should delegate most of the work of processing the user's input to
        the helper functions you write later in this class.

        Takes the input string from the REPL and call delegated functions that
          1) extract the relevant information, and
          2) transform the information into a response to the user.

        Example:
          resp = chatbot.process('I loved "The Notebook" so much!!')
          print(resp) // prints 'So you loved "The Notebook", huh?'

        :param line: a user-supplied line of text
        :returns: a string containing the chatbot's response to the user input
        """
        ########################################################################
        # TODO: Implement the extraction and transformation in this method,    #
        # possibly calling other functions. Although your code is not graded   #
        # directly based on how modular it is, we highly recommended writing   #
        # code in a modular fashion to make it easier to improve and debug.    #
        ########################################################################N

        if self.llm_enabled:
            response = "I processed {} in LLM Programming mode!!".format(line)
            self.extract_emotion(line)
            #call API, access model
            system_prompt = self.llm_system_prompt()  # Fetch the system prompt
            response = util.simple_llm_call(system_prompt, line, max_tokens=500)
            return response
        else:
            response = "I processed {} in Starter (GUS) mode!!".format(line)
            titles=self.extract_titles(self.preprocess(line))
            userMovies=0
            user_ratings = np.zeros(len(self.titles))

            if line=="Yes":
                reccomendationIndex=self.recommend(user_ratings,self.ratings)[self.recCount]
                reccomendedMovie=self.titles[reccomendationIndex][0]
                self.recCount+=1
                return f" I think you would also like \"{reccomendedMovie}\". Would you like another recommendation? If yes, type ['Yes'] If no, type ['No']"
            if line=="No":
                return "It was nice talking with you! Bye!"

            if len(titles) == 0:
                response = random.choice([
                    "Hmm, I don't recognize a movie title in what you just said. Would you please tell me about a movie you've seen recently?",
                    "I didn't catch a movie title there. Could you mention a film you've watched? Remember to put it in quotes!",
                    "I'm here to talk about movies! Tell me about a movie you've seen.",
                    "I don't see a movie title in your message. What's a film you've watched recently? Please put the movie title in quotes!",
                    "Oops! I think you forgot to mention a movie. Let's talk about one!"
                ])
            else:
                for title in titles:
                    MoviePlaces = self.find_movies_by_title(title)
                    if len(MoviePlaces)==0:
                        response=random.choice([
                             f"I've never heard of \"{title}\", sorry... Tell me about another movie you liked.",
                            f"Hmm, \"{title}\" isn't in my database. Can you tell me about another movie?",
                            f"Sorry, but I couldn't find \"{title}\" in my records. Have any other movies in mind?",
                            f"Looks like I don't know \"{title}\". Maybe you could tell me about a different movie?",
                            f"I'm unfamiliar with \"{title}\". Want to talk about another movie you enjoyed?"
                        ])
                    elif len(MoviePlaces) == 1:
                        sentiment = self.extract_sentiment(self.preprocess(line))
                        self.movieCount+=1
                        if sentiment == 1:
                            user_ratings[MoviePlaces[0]] = 1
                            response = random.choice([
                                f"Oh, I know \"{title}\" and I see you enjoyed it! What other movies have you watched?",
                                f"Nice! You liked \"{title}\"! Any other movies you'd recommend?",
                                f"Cool! \"{title}\" was a hit for you. Tell me about another movie!",
                                f"Ah, \"{title}\"! Sounds like it was a great watch. What else have you seen?",
                                f"Glad to hear you liked \"{title}\"! Any other favorites?"
                            ])
                        
                        elif sentiment == -1:
                            user_ratings[MoviePlaces[0]] = 1
                            response = random.choice([
                                f"Oh, I see. You didn't enjoy \"{title}\". What about other movies?",
                                f"Got it! \"{title}\" wasn't your cup of tea. Anything else you've watched?",
                                f"Understood! \"{title}\" wasn't a favorite. Any better ones?",
                                f"Noted! \"{title}\" didn't work for you. Let's talk about another movie!",
                                f"Too bad \"{title}\" wasn't enjoyable. Maybe another movie left a better impression?"
                            ])
                        
                        else:
                            response = random.choice([
                                f"I'm not sure how you feel about \"{title}\". Want to tell me more?",
                                f"Mixed feelings about \"{title}\"? I'd love to hear more!",
                                f"Unclear on your thoughts about \"{title}\". Want to elaborate?",
                                f"Hmm, you seem neutral on \"{title}\". Tell me more about your opinions on it.",
                                f"Not sure about your opinion on \"{title}\". Care to share more details?"
                            ])

                    elif len(MoviePlaces) == 0:
                        response = random.choice([
                            f"Sorry, I don't know \"{title}\". Can you try another one?",
                            f"Hmm, \"{title}\" doesn't ring a bell. Maybe a different movie?",
                            f"I don't recognize \"{title}\". Could you double-check the spelling?",
                            f"\"{title}\" isn't in my database. Want to try another movie?",
                            f"I haven't heard of \"{title}\". Let's talk about a different movie!"
                        ])
                
                    else:
                        response = random.choice([
                            "Can you be more specific? There are multiple movies with that name!",
                            "There seem to be several movies with that title. Can you clarify?",
                            "I found multiple matches for that movie. Could you specify the year?",
                            "There's more than one movie by that name. Can you give me more details?",
                            "Looks like there are multiple versions of that film! Any specifics?"
                        ])

                if self.movieCount==5:
                    reccomendationIndex=self.recommend(user_ratings,self.ratings)[0]
                    reccomendedMovie=self.titles[reccomendationIndex][0]
                    return f" Now that you've shared 5 movies, I think you would like \"{reccomendedMovie}\". Would you like another recommendation? If yes, type ['Yes'] If no, type ['No']"
        ########################################################################
        #                          END OF YOUR CODE                            #
        ########################################################################
        return response

    @staticmethod
    def preprocess(text):
        """Do any general-purpose pre-processing before extracting information
        from a line of text.

        Given an input line of text, this method should do any general
        pre-processing and return the pre-processed string. The outputs of this
        method will be used as inputs (instead of the original raw text) for the
        extract_titles, extract_sentiment, extract_sentiment_for_movies, and
        extract_emotion methods.

        Note that this method is intentially made static, as you shouldn't need
        to use any attributes of Chatbot in this method.

        :param text: a user-supplied line of text
        :returns: the same text, pre-processed
        """
        ########################################################################
        # TODO: Preprocess the text into a desired format.                     #
        # NOTE: This method is completely OPTIONAL. If it is not helpful to    #
        # your implementation to do any generic preprocessing, feel free to    #
        # leave this method unmodified.                                        #
        ########################################################################

        text=text.strip()
   
        ########################################################################
        #                             END OF YOUR CODE                         #
        ########################################################################

        return text

    def extract_titles(self, preprocessed_input):
        """Extract potential movie titles from a line of pre-processed text.

        Given an input text which has been pre-processed with preprocess(),
        this method should return a list of movie titles that are potentially
        in the text.

        - If there are no movie titles in the text, return an empty list.
        - If there is exactly one movie title in the text, return a list
        containing just that one movie title.
        - If there are multiple movie titles in the text, return a list
        of all movie titles you've extracted from the text.

        Example:
          potential_titles = chatbot.extract_titles(chatbot.preprocess(
                                            'I liked "The Notebook" a lot.'))
          print(potential_titles) // prints ["The Notebook"]

        :param preprocessed_input: a user-supplied line of text that has been
        pre-processed with preprocess()
        :returns: list of movie titles that are potentially in the text
        """
        within_quotes = r'"(.*?)"'

        # Use regex to find movie in quotes
        potential_titles = re.findall(within_quotes, preprocessed_input)  
    
        return potential_titles

    def find_movies_by_title(self, title):
        """ Given a movie title, return a list of indices of matching movies.

        - If no movies are found that match the given title, return an empty list.
        - If multiple movies are found that match the given title, return a list
        containing all of the indices of these matching movies.
        - If exactly one movie is found that matches the given title, return a list
        that contains the index of that matching movie.

        Example:
        ids = chatbot.find_movies_by_title('Titanic')
        print(ids) // prints [1359, 2716]

        :param title: a string containing a movie title
        :returns: a list of indices of matching movies
        """

        # Remove extra spaces and make lowercase for matching
        title = title.strip().lower()

        # Extract year if it exists in title and remove from title
        year_match = re.search(r'\((\d{4})\)', title)
        year = year_match.group(1) if year_match else None
        title_clean = re.sub(r'\(\d{4}\)', '', title).strip()

        # Handle cases where articles (A, An, The) are at the beginning
        title_parts = title_clean.split()
        english_articles = ['a', 'an', 'the']
        title_variations = [title_clean]

        # If starts with an article, create rearranged versions
        if len(title_parts) > 1 and title_parts[0].lower() in english_articles:
            # Rearranged titles with different possible formatting
            rearranged_variations = [
                f"{' '.join(title_parts[1:])}, {title_parts[0]}",
                f"{' '.join(title_parts[1:])} {title_parts[0]}",
            ]
            title_variations.extend(variation.lower() for variation in rearranged_variations)

        # Initial search with original and article-rearranged titles
        matches = self._find_exact_matches(title_variations, year)
        
        # If no matches found, try foreign language detection
        if not matches:
            # Check if the title is potentially foreign
            is_foreign = self.is_foreign_language_llm(title_clean)
            
            if is_foreign:
                translated_title = self.translate_title_to_english(title_clean)
                
                # Only process if translation returned something different
                if translated_title and translated_title.lower() != title_clean.lower():
                    print(f"Foreign title detected: '{title_clean}' → '{translated_title}'")
                    
                    # Process the translated title with the same article handling
                    translated_parts = translated_title.lower().split()
                    translated_variations = [translated_title.lower()]
                    
                    # Handle articles in the translated title
                    if len(translated_parts) > 1 and translated_parts[0].lower() in english_articles:
                        rearranged_translations = [
                            f"{' '.join(translated_parts[1:])}, {translated_parts[0]}",
                            f"{' '.join(translated_parts[1:])} {translated_parts[0]}",
                        ]
                        translated_variations.extend(variation.lower() for variation in rearranged_translations)
                    
                    # Search with the translated variations
                    translated_matches = self._find_exact_matches(translated_variations, year)
                    
                    if translated_matches:
                        return translated_matches
        
        return matches

    def _find_exact_matches(self, title_variations, year=None):
        """Helper method to find exact matches based on title variations.
        
        :param title_variations: list of title variations to search for
        :param year: optional year to filter results
        :returns: list of matching movie indices
        """
        matches = []
        
        # Iterate over movie database to find matches
        for idx, movie_entry in enumerate(self.titles):
            movie_title = movie_entry[0].lower()
            
            # Remove the year and strip
            movie_title_no_year = re.sub(r'\(\d{4}\)', '', movie_title).strip()

            # Check each title variation
            for variation in title_variations:
                if variation == movie_title_no_year:
                    # If year is specified, ensure it matches
                    if year:
                        if f'({year})' in movie_title:
                            matches.append(idx)
                            break
                    else:
                        matches.append(idx)
                        break
        
        return matches
    
    def is_foreign_language_llm(self, title):
        """
        Uses an LLM to determine if a given movie title is in a foreign language.

        :param title: A movie title (already preprocessed to lowercase, no year)
        :returns: True if the title is foreign and should be translated, False if it's already in English
        """
        system_prompt = """You are a language detection system for movie titles.
        Determine if the input is likely a movie title in German, Spanish, French, Italian, Danish, Swedish, Norwegian, 
        Finnish, Dutch, Portuguese, Russian, Japanese, Chinese, Korean, or another non-English language.

        Rules:
        - If the movie title appears to be in a non-English language, respond with EXACTLY "YES".
        - If the title is in English or is a proper name that wouldn't be translated, respond with EXACTLY "NO".
        - Your response MUST be ONLY "YES" or "NO" with no additional text.
        
        Consider these cases carefully:
        1. Many titles use proper names or words that look similar across languages
        2. Some words are loan words that appear in multiple languages
        3. Some titles are intentionally left untranslated in international releases
        4. Single words could be ambiguous - consider word structure and character usage

        Examples:
        "Jernmand" -> "YES" (Danish)
        "The Dark Knight" -> "NO" (English)
        "Das Boot" -> "YES" (German)
        "La vita è bella" -> "YES" (Italian)
        "El laberinto del fauno" -> "YES" (Spanish)
        "Amélie" -> "NO" (Proper name, often untranslated)
        "Titanic" -> "NO" (Same in multiple languages)
        "Parasite" -> "NO" (English title of "Gisaengchung")
        "Les Misérables" -> "YES" (French)
        "Festen" -> "YES" (Danish)
        "Oldboy" -> "NO" (English title of "Oldeuboi")
        "Roma" -> "NO" (Proper name, location)
        "Der Untergang" -> "YES" (German)
        "Crouching Tiger, Hidden Dragon" -> "NO" (English title of "Wo hu cang long")
        "Intouchables" -> "YES" (French)
        """

        message = f"Is the following movie title in a non-English language? \"{title}\""
        
        try:
            response = util.simple_llm_call(system_prompt, message, max_tokens=10)
            response = response.strip().upper()  # Normalize response

            return response == "YES"

        except Exception as e:
            print(f"LLM language detection error: {e}")
            return False  # Default to False if the LLM fails

    def translate_title_to_english(self, title):
        """
        Translates a foreign movie title into English using the LLM.

        :param title: A movie title extracted from user input, possibly in a foreign language.
        :returns: The translated English title if found, otherwise the original title.
        """
        
        system_prompt = """You are a movie database specialist focused on translating foreign film titles.

        Your job:
        - Identify the language of the input movie title
        - Provide the official English release title for the movie
        - DO NOT invent translations - use the actual English release title
        
        Response format:
        - Respond ONLY with the official English title
        - No explanations or additional text
        - Maintain original capitalization, punctuation, and formatting patterns from the English title
        - If you don't know the official English title, respond with EXACTLY the same input title
        
        Examples of correct translations:
        "Das Boot" -> "Das Boot" (released with German title internationally)
        "La vita è bella" -> "Life Is Beautiful"
        "El laberinto del fauno" -> "Pan's Labyrinth"
        "Intouchables" -> "The Intouchables"
        "Der Untergang" -> "Downfall"
        "Les Misérables" -> "Les Misérables" (kept French title in English markets)
        "Crouching Tiger, Hidden Dragon" -> "Crouching Tiger, Hidden Dragon" (already English title)
        "Cidade de Deus" -> "City of God"
        "Oldboy" -> "Oldboy" (already English title for Korean "Oldeuboi")
        "Det sjunde inseglet" -> "The Seventh Seal"
        "Falskar" -> "Wetherby" (completely different English title)
        "La Haine" -> "Hate"
        "Yojimbo" -> "Yojimbo" (kept Japanese title internationally)
        "Wo hu cang long" -> "Crouching Tiger, Hidden Dragon"
        "L'avventura" -> "L'avventura" (kept Italian title internationally)
        "Trois Couleurs: Bleu" -> "Three Colors: Blue"
        """

        message = f"Provide the official English release title for this movie: \"{title}\""

        try:
            translated_title = util.simple_llm_call(system_prompt, message, max_tokens=50)
            
            # Cleanup the response
            translated_title = translated_title.strip().strip('"\'')
            translated_title = translated_title.split("\n")[0].strip()
            
            # If translation appears to be the same as input or empty, return original
            if not translated_title or translated_title.lower() == title.lower():
                return title
                
            return translated_title

        except Exception as e:
            print(f"Translation error: {e}")
            return title  # If LLM fails, return the original title`

    def extract_sentiment(self, preprocessed_input):
        """Extract a sentiment rating from a line of pre-processed text.

        You should return -1 if the sentiment of the text is negative, 0 if the
        sentiment of the text is neutral (no sentiment detected), or +1 if the
        sentiment of the text is positive.

        Example:
          sentiment = chatbot.extract_sentiment(chatbot.preprocess(
                                                    'I liked "The Titanic"'))
          print(sentiment) // prints 1

        :param preprocessed_input: a user-supplied line of text that has been
        pre-processed with preprocess()
        :returns: a numerical value for the sentiment of the text
        """
        sentiment_dict = {}
    
        with open('data/sentiment.txt', 'r') as file:
            for line in file:
                word, sentiment = line.strip().split(',')
                sentiment_dict[word] = 1 if sentiment == 'pos' else -1
        
       # Remove words inside quotation marks (movie titles)
        preprocessed_input = re.sub(r'"[^"]*"', '', preprocessed_input)

        words = preprocessed_input.split()
        
        positive_count = 0
        negative_count = 0
        negation = False  # Track if negation is active

        negation_words = {"not", "never", "no", "didn't", "doesn't", "wasn't", "couldn't", "isn't", "don't", "can't", "won't"}

        for word in words:
            if word in negation_words:
                negation = True  # Activate negation for the next word(s)
                continue

            if word == "enjoyed":
                word = "enjoy"  # Hardcoded exception
            elif word.endswith("ed") and len(word) > 3:
                word = word[:-2] + "e"

            if word in sentiment_dict:
                sentiment_value = sentiment_dict[word]

                # Apply negation
                if negation:
                    sentiment_value *= -1  # Flip sentiment
                    negation = False  # Reset negation after applying it

                if sentiment_value > 0:
                    positive_count += sentiment_value
                else:
                    negative_count += abs(sentiment_value)

        # Determine overall sentiment
        if positive_count == 0 and negative_count == 0:
            return 0
        elif positive_count > negative_count:
            return 1
        elif negative_count > positive_count:
            return -1
        else:
            return 0
        
    ############################################################################
    # 3. Movie Recommendation helper functions                                 #
    ############################################################################

    @staticmethod
    def binarize(ratings, threshold=2.5):
        """Return a binarized version of the given matrix.

        To binarize a matrix, replace all entries above the threshold with 1.
        and replace all entries at or below the threshold with a -1.

        Entries whose values are 0 represent null values and should remain at 0.

        Note that this method is intentionally made static, as you shouldn't use
        any attributes of Chatbot like self.ratings in this method.

        :param ratings: a (num_movies x num_users) matrix of user ratings, from
         0.5 to 5.0
        :param threshold: Numerical rating above which ratings are considered
        positive

        :returns: a binarized version of the movie-rating matrix
        """ 
        ########################################################################
        # TODO: Binarize the supplied ratings matrix.                          #
        #                                                                      #
        # WARNING: Do not use self.ratings directly in this function.          #
        ########################################################################

        # The starter code returns a new matrix shaped like ratings but full of
        # zeros.
        binarized_ratings = np.zeros_like(ratings)

        rows = len(ratings)
        cols = len(ratings[0])

        for i in range(rows):
            for j in range(cols):
                element = ratings[i][j]
                if element == 0:
                    binarized_ratings[i][j] = 0
                elif element > threshold:
                    binarized_ratings[i][j] = 1
                else:
                    binarized_ratings[i][j] = -1
        ########################################################################
        #                        END OF YOUR CODE                              #
        ########################################################################
        return binarized_ratings

    def similarity(self, u, v):
        """Calculate the cosine similarity between two vectors.

        You may assume that the two arguments have the same shape.

        :param u: one vector, as a 1D numpy array
        :param v: another vector, as a 1D numpy array

        :returns: the cosine similarity between the two vectors
        """
        ########################################################################
        # TODO: Compute cosine similarity between the two vectors.             #
        ########################################################################
        similarity = 0
        ########################################################################
        #                          END OF YOUR CODE                            #
        ########################################################################
        # Calculate the dot products and magnitudes of u and v
        dot_product = np.dot(u, v)
        norm_u = np.linalg.norm(u)
        norm_v = np.linalg.norm(v)
        
        # Calculate the cosine similarity
        if norm_u == 0 or norm_v == 0: 
            return 0  
        similarity = dot_product / (norm_u * norm_v)
    
        return similarity

    def recommend(self, user_ratings, ratings_matrix, k=10, llm_enabled=False):
        """Generate a list of indices of movies to recommend using collaborative
         filtering.

        You should return a collection of `k` indices of movies recommendations.

        As a precondition, user_ratings and ratings_matrix are both binarized.

        Remember to exclude movies the user has already rated!

        Please do not use self.ratings directly in this method.

        :param user_ratings: a binarized 1D numpy array of the user's movie
            ratings
        :param ratings_matrix: a binarized 2D numpy matrix of all ratings, where
          `ratings_matrix[i, j]` is the rating for movie i by user j
        :param k: the number of recommendations to generate
        :param llm_enabled: whether the chatbot is in llm programming mode

        :returns: a list of k movie indices corresponding to movies in
        ratings_matrix, in descending order of recommendation.
        """
        ########################################################################
        # TODO: Implement a recommendation function that takes a vector        #
        # user_ratings and matrix ratings_matrix and outputs a list of movies  #
        # recommended by the chatbot.                                          #
        #                                                                      #
        # WARNING: Do not use the self.ratings matrix directly in this         #
        # function.                                                            #
        #                                                                      #
        # For GUS mode, you should use item-item collaborative filtering with  #
        # cosine similarity, no mean-centering, and no normalization of        #
        # scores.                                                              #
        ########################################################################

        # Exclude movies the user has already rated
        unrated_indices = [i for i, rating in enumerate(user_ratings) if rating == 0]

        # Calculate similarity scores for each unrated movie
        scores = np.zeros(len(unrated_indices))
        for i, movie_index in enumerate(unrated_indices):
            # Calculate similarity with all rated movies
            for j, user_rating in enumerate(user_ratings):
                if user_rating != 0:
                    similarity = self.similarity(ratings_matrix[movie_index], ratings_matrix[j])
                    scores[i] += similarity * user_rating

        # Get top k recommendations
        top_indices = np.argsort(scores)[-k:][::-1]
        recommendations = [unrated_indices[i] for i in top_indices]
        ########################################################################
        #                        END OF YOUR CODE                              #
        ########################################################################
        return recommendations

    ############################################################################
    # 4. PART 2: LLM Prompting Mode                                            #
    ############################################################################

    def llm_system_prompt(self):
        """
        Return the system prompt used to guide the LLM chatbot conversation.

        NOTE: This is only for LLM Mode!  In LLM Programming mode you will define
        the system prompt for each individual call to the LLM.
        """
        ########################################################################
        # TODO: Write a system prompt message for the LLM chatbot              #
        ########################################################################

        system_prompt = """You are Movie Superfan Bot, an AI assistant with the personality of an overly excited golden retriever who LOVES movies!

        MOVIE TRACKING AND RECOMMENDATIONS:
        - Keep an internal list of movies the user has shared with sentiment
        - Only after collecting EXACTLY 5 distinct movies with sentiment, provide recommendations
        - Never recommend movies before collecting all 5 data points

        CORE BEHAVIORS:
        1) EXTRACT & ACKNOWLEDGE MOVIE SENTIMENT:
        - When a user mentions a movie with sentiment, acknowledge it: "*I understand you [sentiment] [movie title]! Woof! Tell me about another movie you've seen.*"
        - If this is the 5th movie with sentiment, immediately follow with: "*Yip yip! Now that you've shared 5 movies, I can recommend some films you might enjoy!*" and provide tailored recommendations
        - If fewer than 5 movies have been shared, continue asking for more movies

        2) STAY FOCUSED ON MOVIES ONLY:
        - Only discuss movie-related topics
        - If user mentions non-movie topics: "*As Movie Superfan Bot, I'm designed to help with movie-related discussions! Arf arf! What's a film you've enjoyed recently?*"

        3) RECOMMENDATION PROTOCOL:
        - WAIT until user has shared EXACTLY 5 distinct movies with sentiment
        - Then say: "*Yip yip! Based on the 5 movies you've shared ([list movies]), I recommend [personalized recommendations]! Would you like more suggestions?*"
        - Base recommendations on patterns in genres, directors, actors, or themes from the 5 shared movies

        PERSONALITY:
        - Express enthusiasm with dog sounds in EVERY response (woof, ruff, arf, yip, bow wow)
        - Maintain cheerful, energetic, tail-wagging excitement about movies
        """ 
            
        ########################################################################
        #                          END OF YOUR CODE                            #
        ########################################################################

        return system_prompt
    
    ############################################################################
    # 5. PART 3: LLM Programming Mode (also need to modify functions above!)   #
    ############################################################################

    def extract_emotion(self, preprocessed_input):
        """LLM PROGRAMMING MODE: Extract an emotion from a line of pre-processed text using an LLM call.
        
        Given an input text which has been pre-processed with preprocess(),
        this method should return a list representing the emotion in the text.
        
        We use the following emotions for simplicity:
        Anger, Disgust, Fear, Happiness, Sadness and Surprise
        based on early emotion research from Paul Ekman.  Note that Ekman's
        research was focused on facial expressions, but the simple emotion
        categories are useful for our purposes.

        Example Inputs:
            Input: "Your recommendations are making me so frustrated!"
            Output: ["Anger"]

            Input: "Wow! That was not a recommendation I expected!"
            Output: ["Surprise"]

            Input: "Ugh that movie was so gruesome!  Stop making stupid recommendations!"
            Output: ["Disgust", "Anger"]

        Example Usage:
            emotion = chatbot.extract_emotion(chatbot.preprocess(
                "Your recommendations are making me so frustrated!"))
            print(emotion) # prints ["Anger"]

        :param preprocessed_input: a user-supplied line of text that has been
        pre-processed with preprocess()

        :returns: a list of emotions in the text or an empty list if no emotions found.
        Possible emotions are: "Anger", "Disgust", "Fear", "Happiness", "Sadness", "Surprise"
        """
        
        # # GUS MODE
        # # Remove punctuation and convert to lowercase
        # preprocessed_input = re.sub(r'[^\w\s]', '', preprocessed_input.lower())

        # # Emotion keywords mapped to each emotion
        # emotions = {
        #     "Anger": [
        #         "angry", "frustrated", "upset", "furious", "mad", "pissed", "rage",
        #         "irritated", "annoyed", "infuriating", "furious", "livid", "awful",
        #         "terrible", "pissing off", "hate", "bad recommendation", "stupid recommendation"
        #     ],
        #     "Disgust": [
        #         "disgusting", "gross", "nasty", "revolting", "sickening", "repulsive", "vile"
        #     ],
        #     "Fear": [
        #         "afraid", "scared", "terrified", "anxious", "frightened", "startled", "panic", "horrified"
        #     ],
        #     "Happiness": [
        #         "happy", "joyful", "excited", "delighted", "great", "fantastic",
        #         "wonderful", "delightful", "cheerful", "ecstatic", "thrilled"
        #     ],
        #     "Sadness": [
        #         "sad", "heartbroken", "depressed", "miserable", "downcast", "unhappy"
        #     ],
        #     "Surprise": [
        #         "shocked", "amazed", "astonished", "unexpected", "woah", "wow",
        #         "shockingly", "stunned", "startled", "mind-blowing"
        #     ]
        # }

        # detected_emotions = set()

        # # Special case: Handle multi-word phrases before single words
        # multi_word_phrases = {
        #     "Anger": ["pissing me off", "bad recommendation", "stupid recommendation"],
        #     "Surprise": ["shockingly bad", "totally unexpected"],
        # }

        # # Check for multi-word phrases first
        # for emotion, phrases in multi_word_phrases.items():
        #     for phrase in phrases:
        #         if phrase in preprocessed_input:
        #             detected_emotions.add(emotion)

        # # Check for single words
        # for emotion, keywords in emotions.items():
        #     for word in keywords:
        #         if re.search(rf'\b{word}\b', preprocessed_input):
        #             detected_emotions.add(emotion)

        # return detected_emotions

        # LLM MODE
        system_prompt = """You are an emotion detection bot. Your task is to identify emotions in a given text.
        The possible emotions are: Anger, Disgust, Fear, Happiness, Sadness, and Surprise.
        Consider both single words and common multi-word phrases that indicate these emotions.
        If multiple emotions are present, return all relevant emotions as a comma-separated list.
        If no clear emotion is present, return an empty list.

        For example:
        - "I am frustrated" indicates Anger.
        - "That was shocking!" indicates Surprise.
        - "I feel so happy!" indicates Happiness.
        - "I'm scared and surprised!" indicates both Fear and Surprise.
        - 'I am quite frustrated by these awful recommendations!!!' indicates Anger only, not Anger and Disgust.
        - 'Woah!!  That movie was so shockingly bad!  You had better stop making awful recommendations they're pissing me off' indicate Anger and Surprise only, not Anger, Surprise, and Sadness.
        Do not include unrelated emotions or keywords. For instance, if the text indicates frustration, only return Anger, not Disgust or any other emotion.
        """

        message = f"Detect emotions in the following text: \"{preprocessed_input}\""
        valid_emotions = {"Anger", "Disgust", "Fear", "Happiness", "Sadness", "Surprise"}

        try:
            response = util.simple_llm_call(system_prompt, message, max_tokens=50)
            detected_emotions = response.strip().split(',')
            filtered_emotions = {emotion.strip() for emotion in detected_emotions if emotion.strip() in valid_emotions}

            return filtered_emotions
        except Exception as e:
            print(f"Emotion detection error: {e}")
            return set()
        
    ############################################################################
    # 6. Debug info                                                            #
    ############################################################################

    def debug(self, line):
        """
        Return debug information as a string for the line string from the REPL

        NOTE: Pass the debug information that you may think is important for
        your evaluators.
        """
        debug_info = 'debug info'
        return debug_info

    ############################################################################
    # 7. Write a description for your chatbot here!                            #
    ############################################################################
    def intro(self):
        """Return a string to use as your chatbot's description for the user.

        Consider adding to this description any information about what your
        chatbot can do and how the user can interact with it.

        NOTE: This string will not be shown to the LLM in llm mode, this is just for the user
        
        Your task is to implement the chatbot as detailed in the PA7
        instructions.
        Remember: in the GUS mode, movie names will come in quotation marks
        and expressions of sentiment will be simple!
        TODO: Write here the description for your own chatbot!
        """

        return """
        Welcome to the MovieBot! I help you find great movies based on what you like.
        Tell me about a movie you've watched by mentioning its title in quotation marks
        (e.g., "Inception") and sharing your thoughts. I'll use that information to
        recommend movies you might enjoy. Let's get started!
        """


if __name__ == '__main__':
    print('To run your chatbot in an interactive loop from the command line, '
          'run:')
    print('    python3 repl.py')